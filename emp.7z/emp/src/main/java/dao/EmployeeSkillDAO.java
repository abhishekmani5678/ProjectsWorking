package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import database.DBConnection;
import entity.EmployeeSkill;

public class EmployeeSkillDAO {
	DBConnection dbConnection=null;
	Connection connection=null;
	
	public List<EmployeeSkill> getAllSkillId(int employeeId){
		List<EmployeeSkill> employeeSkill=new ArrayList<EmployeeSkill>();
		EmployeeSkill skillId=null;
		
		String getSkill="select skillId from EmployeeSkillA where employeeId=?";
		 
		 try {
			 dbConnection=new DBConnection();
		 connection=dbConnection.getConnection();
		 System.out.println("In skillMaster table Database Connected");
		 
		 PreparedStatement preparedStatement=connection.prepareStatement(getSkill);
		preparedStatement.setInt(1,employeeId);
		 ResultSet resultSet=preparedStatement.executeQuery();
		 while(resultSet.next()) {
			 skillId=new EmployeeSkill();
			 
			 skillId.setSkillId(resultSet.getInt(1));
			 employeeSkill.add(skillId);
		 
		 }
		 
		
		 }catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return employeeSkill;
	}
	
	public boolean deleteSkillDetailsByIdForUpdate(int employeeId) {
		
		boolean deleteSkillResult=true;
		
		 String foreignTableDeleteQuery="delete from EmployeeSkillA where employeeId=?";
		
		 try{
			 dbConnection=new DBConnection();
			 PreparedStatement preparedStatement=connection.prepareStatement(foreignTableDeleteQuery);
			 preparedStatement.setInt(1, employeeId);
			 
			 int result=preparedStatement.executeUpdate();
			 System.out.println("Result------------------------------------------------------------"+"Data Deleted"+"["+result+"]");
			 
			 
		connection=dbConnection.getConnection();
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		 
		 //CLosing the COnnection
		 finally {
			 try {
				 connection.close();
				 connection=null;
			 }catch(Exception e) {
				 e.printStackTrace();
			 }
		 }
		
		return deleteSkillResult;
		
		
		
	}
	
	
	

}
