package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import database.DBConnection;
import entity.Employee;
import entity.EmployeeSkill;

public class EmployeeDAO {
	Connection connection = null;
	DBConnection dbConnection = null;
	private int noOfRecords;

	// Insert Employee details into DataBase
	public int saveEmployee(Employee employee, String[] skills) {

		DBConnection dbConnection = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			long l = employee.getBirthDate().getTime();
			java.sql.Date sdate = new java.sql.Date(l);
			String sql = "INSERT INTO EmployeeA (name,address,gender,salary,birthDate)VALUES(?,?,?,?,?)";
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setString(2, employee.getAddress());
			preparedStatement.setByte(3, employee.getGender());
			preparedStatement.setDouble(4, employee.getSalary());
			preparedStatement.setDate(5, sdate);

			int dataStatus = preparedStatement.executeUpdate();
			ResultSet resultSet = preparedStatement.getGeneratedKeys();

			if (resultSet.next()) {
				int generatedKey = resultSet.getInt(1);
				System.out.println("the inserted employee Id" + generatedKey);

				for (String skillId : skills) {
					EmployeeSkill employeeSkill=new EmployeeSkill();
				    employeeSkill.setEmployeeId(generatedKey);
				    employeeSkill.setSkillId(Integer.parseInt(skillId));
					
					
					
					
//				employeeSkill.setEmployeeId(generatedKey);
//			employeeSkill.setSkillId(Integer.parseInt(skillId));
					insertEmployeeSkill(employeeSkill);
				}
			}
			if (dataStatus >= 1) {
				System.out.println("Data Inserted SuceesFully");
				return dataStatus;

			} else {
				System.out.println("oops there is error Employee ");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (dbConnection != null) {
					dbConnection.close();
				}
			} catch (Exception exception2) {
				exception2.printStackTrace();
			}
		}
		return 0;

	}

//Inserting Data into Skill Data 	
	public boolean insertEmployeeSkill(EmployeeSkill employeeSkill) {
		boolean skillStatus = false;
		DBConnection dbConnection = null;
		Connection connection = null;

		PreparedStatement preparedStatement = null;
		try {
			String sql = "INSERT INTO EmployeeSkillA (employeeId,skillId)VALUES(?,?)";
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			System.out.println("employee Id" + " " + employeeSkill.getEmployeeId());
			System.out.println("skill master id " + " " + employeeSkill.getSkillId());
			preparedStatement.setInt(1, employeeSkill.getEmployeeId());
			preparedStatement.setInt(2, employeeSkill.getSkillId());
			int dataStatus = preparedStatement.executeUpdate();
			if (dataStatus >= 1) {
				System.out.println("Data Inserted SuceesFully");
				return skillStatus;

			} else {
				System.out.println("oops there is error EmployeeSkill ");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (dbConnection != null) {
					dbConnection.close();
				}
			} catch (Exception exception2) {
				exception2.printStackTrace();
			}
		}
		return skillStatus;

	}

	// Get Employee Details from Employee Data from the EmployeeA
	public List<Employee> getEmployeeDetails(int pageNumber, int pageSize) {

		List<Employee> list = new ArrayList<Employee>();
		Employee employee = null;
		String fetchEmpDataQuery = "SELECT * FROM EmployeeA ORDER BY employeeId OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

		// Connecting Database connection and fetching the query
		try {
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(fetchEmpDataQuery);

			 int offset = (pageNumber - 1) * pageSize;
	            preparedStatement.setInt(1, offset);
	            preparedStatement.setInt(2, pageSize);


			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				employee = new Employee();

				employee.setEmployeeId(resultSet.getInt(1));
				employee.setName(resultSet.getString(2));
				employee.setAddress(resultSet.getString(3));
				employee.setGender(resultSet.getByte(4));
				employee.setSalary(resultSet.getDouble(5));
				employee.setBirthDate(resultSet.getDate(6));

				list.add(employee);
			}

		} catch (Exception e) {
			e.printStackTrace();

			// Closing the Database Connection
		} finally {
			try {
				connection.close();
				connection = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return list;

	}

	// Delete Employee Details By id
	public boolean deleteEmployeeDetails(int employeeId) {
		boolean resultStatus = false;

		String foreignTableDeleteQuery = "delete from EmployeeSkillA where employeeId=?";
		String employeeTableDeleteQuery = "delete from EmployeeA where employeeId=?";
		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;

		try {
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			preparedStatement1 = connection.prepareStatement(foreignTableDeleteQuery);
			preparedStatement1.setInt(1, employeeId);
			int result = preparedStatement1.executeUpdate();

			if (result >= 1) {

				preparedStatement2 = connection.prepareStatement(employeeTableDeleteQuery);
				preparedStatement2.setInt(1, employeeId);

				int result2 = preparedStatement2.executeUpdate();
				if (result2 >= 1) {
					resultStatus = true;
					System.out.println("Data deleted SucessFully");
				} else {
					System.out.println("Data not deleted");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();

			// Closing the Database Connection
		} finally {
			try {
				connection.close();
				connection = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return resultStatus;

	}

	// Getting Employee Details by Employeeid
	public List<Employee> getEmployeeDetailsById(int employeeId) {
		List<Employee> employeeDetails = new ArrayList<Employee>();
		Employee employee = null;

		String getEmployeeDetailsQuery = "select * from EmployeeA where employeeId=?";

		try {
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			System.out.println("Database Connected");

			PreparedStatement preparedStatement = connection.prepareStatement(getEmployeeDetailsQuery);
			preparedStatement.setInt(1, employeeId);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				employee = new Employee();
				// skill=new Skill();
				employee.setEmployeeId(resultSet.getInt(1));
				employee.setName(resultSet.getString(2));
				employee.setAddress(resultSet.getString(3));
				employee.setGender(resultSet.getByte(4));
				employee.setSalary(resultSet.getDouble(5));
				employee.setBirthDate(resultSet.getDate(6));

				employeeDetails.add(employee);

			}

		} catch (Exception e) {
			e.printStackTrace();

			// Closing the Database Connection
		} finally {
			try {
				connection.close();
				connection = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return employeeDetails;

	}

	// UPDATE EMPLOYEE DETAILS BASED ON EMPLOYEE ID
	public boolean upadateEmployeeDetailsById(Employee employee,String[] skills) {
		boolean updateStatus2=false;
		String deleteSkillEmpId = "DELETE FROM EmployeeSkillA WHERE employeeId=?";
		String updateEmployeeQuery = "update employeeA set name=?,address=?,gender=?, salary=?,birthDate=?  where employeeId=?";
//		String updateEmployeeSKillDetails="insert into EmployeeSkill(employeeId,skillId) values(?,?)";
		
		try {
			dbConnection = new DBConnection();
			connection = dbConnection.getConnection();
			
			
			
			//1.Firing The Query for Data updation 
			PreparedStatement preparedStatement = connection.prepareStatement(deleteSkillEmpId);
			preparedStatement.setInt(1, employee.getEmployeeId());
			 preparedStatement.executeUpdate();
			 
			 
			 long l = employee.getBirthDate().getTime();
			java.sql.Date sdate = new java.sql.Date(l);
		    preparedStatement = connection.prepareStatement(updateEmployeeQuery);
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setString(2, employee.getAddress());
			preparedStatement.setByte(3, employee.getGender());
			preparedStatement.setDouble(4, employee.getSalary());

			preparedStatement.setDate(5, sdate);
			preparedStatement.setInt(6, employee.getEmployeeId());

			//2. query firing for Data updation
			int updateStatus = preparedStatement.executeUpdate();

			//After Updation insert data into EmployeeSKill
			for (String skillId : skills) {
				EmployeeSkill employeeSkill=new EmployeeSkill();
			    employeeSkill.setEmployeeId(employee.getEmployeeId());
			    employeeSkill.setSkillId(Integer.parseInt(skillId));
				
			    insertEmployeeSkill(employeeSkill);
			    updateStatus2=true;
			}
				
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			try {
				connection.close();
				connection = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return updateStatus2;

	}
	
}
