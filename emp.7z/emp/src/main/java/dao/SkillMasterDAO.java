package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import database.DBConnection;
import entity.SkillMaster;

public class SkillMasterDAO {
	Connection connection=null;
	DBConnection dbConnection=null;
	
	//Get Data From SkillMaster table
	public List<SkillMaster> getAllSkill(){
		List<SkillMaster> skillMasterList=new ArrayList<SkillMaster>();
		SkillMaster skillList =null;
		
		try {
			dbConnection=new DBConnection(); 
			connection = dbConnection.getConnection();
			String getSkillQuery="select * from SkillMasterA";
			PreparedStatement preparedStatement=connection.prepareStatement(getSkillQuery);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
					{
				skillList=new SkillMaster ();
				skillList.setSkillId(resultSet.getInt(1));
				skillList.setSkillName(resultSet.getString(2));
				skillMasterList.add(skillList);
					}
		
		}catch(Exception e) {
			e.printStackTrace();
		
		
		
		
		}finally {
			if(connection!=null)
			try {
				connection.close();
				connection=null;
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return skillMasterList;
	}
	
}