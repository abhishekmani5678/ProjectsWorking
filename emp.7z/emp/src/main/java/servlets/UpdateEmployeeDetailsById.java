package servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmployeeDAO;
import dao.EmployeeSkillDAO;
import dao.SkillMasterDAO;
import entity.Employee;
import entity.EmployeeSkill;
import entity.SkillMaster;


@WebServlet("/updateEmployee")
public class UpdateEmployeeDetailsById extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Inside we intered do Post");
		 int employeeId =Integer.parseInt(request.getParameter("employeeId"));
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		 byte gender =Byte.parseByte(request.getParameter("gender"));
		System.out.println(gender+"------------------------------------------");
		System.out.println("In update servlet Page!");
		
		double salary=Double.parseDouble(request.getParameter("salary"));
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

		Date birthdate = null;
				try {
					birthdate = dateFormat.parse(request.getParameter("birthdate"));
				} catch (Exception e) {
					e.printStackTrace();
				}
	    System.out.println("the main boss of project"+employeeId);
		System.out.println("name edit in post "+name);
		System.out.println(address);
		System.out.println(gender);
		System.out.println(salary);
	
		  String skills[]=request.getParameterValues("skills");
		        	if(skills!=null) {
		        		for(int i=0;i<skills.length;i++) {
		        			System.out.println("Skill Id's :"+"[" + i + "]=" + skills[i]);
		        			
		        		}
		        	}

		      Employee employee=new Employee(employeeId,name,address,gender,salary,birthdate);  	
		        	
		      EmployeeDAO employeeDAO=new EmployeeDAO();
		      boolean result=employeeDAO.upadateEmployeeDetailsById(employee, skills);
		      if(result) {
		    	  System.out.println("Data updated SucessFully");
		    	 response.sendRedirect("index.jsp");
		      }else {
		    	  System.out.println("Opps! something went wrong data not updated ");
		      }
		
	}
	 
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int employeeId=Integer.parseInt(req.getParameter("employeeId"));
		
		  System.out.println("edit employee id get 's id"+employeeId);
		  
		  EmployeeDAO employeeDAO=new EmployeeDAO();
		  EmployeeSkillDAO employeeSKillDAO=new EmployeeSkillDAO();
		  SkillMasterDAO dao=new SkillMasterDAO();
		  
		  List<EmployeeSkill> skillId=  employeeSKillDAO.getAllSkillId(employeeId);
		  System.out.println("Get skills detials by id for Updating process in do get Method"+skillId);
		  req.setAttribute("skillEmoloyees",skillId);
		
		  System.out.println("================================================");
		 
		  
		List<Employee> employeeDetails= employeeDAO.getEmployeeDetailsById(employeeId);
		  System.out.println("Get Employee detials by id for Updating process in do get Method"+employeeDetails);
		     req.setAttribute("getAllEmployee",employeeDetails);
		   
		     
		     
		     
		    
		     List<SkillMaster> allSkill=dao.getAllSkill();
			   System.out.println("all skill print in this "+allSkill);
			    req.setAttribute("Allskill",allSkill);
		    
			    
			    
			 RequestDispatcher dispatcher = req.getRequestDispatcher("updateEmployee.jsp");
		     dispatcher.forward(req, resp);
	}
	
	
	}
 

		

