package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmployeeDAO;
import dao.EmployeeSkillDAO;
import entity.Employee;
import entity.EmployeeSkill;

@WebServlet("/get-emp-details")
public class GetEmployeeDeatilsById extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int employeeId=Integer.parseInt(request.getParameter("employeeId"));
		
		
		
		  System.out.println("id  of employee "+employeeId);
		EmployeeDAO employeeDAO=new EmployeeDAO();
		List<Employee> employeeDetails=employeeDAO.getEmployeeDetailsById(employeeId);
		
		EmployeeSkillDAO employeeSKillDAO=new EmployeeSkillDAO();
		List<EmployeeSkill> employeeSkillId=employeeSKillDAO.getAllSkillId(employeeId);
		System.out.println("employee  details"+employeeDetails);
		
		System.out.println("employee skill Id"+employeeSkillId);
		
		request.setAttribute("listofEmployee", employeeDetails);
		request.setAttribute("listofselectskillid", employeeSkillId);
		  RequestDispatcher dispatcher = request.getRequestDispatcher("update-emp-details.jsp");
	        dispatcher.forward(request, response);
		
		

		
	}
	}


