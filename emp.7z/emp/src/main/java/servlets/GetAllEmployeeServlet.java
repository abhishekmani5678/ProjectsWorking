package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmployeeDAO;
import entity.Employee;

@WebServlet("/getAllEmployee")
public class GetAllEmployeeServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private EmployeeDAO employeeDAO; // Initialize this before using it
	private int pageSize = 5; // Set your desired page size

	@Override
	public void init() throws ServletException {
		// Initialize the employeeDAO here
		employeeDAO = new EmployeeDAO();
	 
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String pageParam = req.getParameter("page");
		int pageNumber;

		if (pageParam != null && !pageParam.isEmpty()) {
			try {
				pageNumber = Integer.parseInt(pageParam);
			} catch (NumberFormatException e) {

				pageNumber = 1;

			}
		} else {

			pageNumber = 1;

		}

		List<Employee> employeeList = employeeDAO.getEmployeeDetails(pageNumber, pageSize);
		System.out.println("all employee by click get all employee " + employeeList);
		req.setAttribute("getAllEmployee", employeeList);
		req.setAttribute("page", pageNumber);
		req.setAttribute("pageSize", pageSize);

		
		RequestDispatcher dispatcher = req.getRequestDispatcher("getAllEmployee.jsp");
		dispatcher.forward(req, resp);
	}
}
