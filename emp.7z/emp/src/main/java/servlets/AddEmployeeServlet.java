package servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeDAO;
import dao.SkillMasterDAO;
import entity.Employee;
import entity.SkillMaster;

@WebServlet("/addEmployee")
public class AddEmployeeServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	 @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String name=request.getParameter("name");
			String address=request.getParameter("address");
			byte gender=Byte.parseByte(request.getParameter("gender"));
			System.out.println(gender+"------------------------------------------");
			
			double salary=Double.parseDouble(request.getParameter("salary"));
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

			Date birthdate = null;
					try {
						birthdate = dateFormat.parse(request.getParameter("birthdate"));
					} catch (Exception e) {
						e.printStackTrace();
					}
			System.out.println(name);
			System.out.println(address);
			System.out.println(gender);
			System.out.println(salary);
		
			  String skills[]=request.getParameterValues("skills");
			        	if(skills!=null) {
			        		for(int i=0;i<skills.length;i++) {
			        			System.out.println("Skill Id's :"+"[" + i + "]=" + skills[i]);
			        			
			        		}
			        	}
			        	
			  Employee employee=new Employee(name,address,gender,salary,birthdate);
			
			EmployeeDAO employeeDAO=new EmployeeDAO();
			int insertData=employeeDAO.saveEmployee(employee,skills);
			
		    if(insertData>0) {
		    	System.out.println("data inserted sucessfully");
		    	
		    	
				List<Employee> employeeList=employeeDAO.getEmployeeDetails(1,7);
		    	 System.out.println("all employee  print after insertsd succesfully "+employeeList);
		    	 
				    request.setAttribute("getAllEmployee",employeeList);
				  RequestDispatcher dispatcher = request.getRequestDispatcher("getAllEmployee.jsp");
			        dispatcher.forward(request, response);
		    	
		    }
		    else {
		    	System.out.println("data not inserted properly");
		    	 RequestDispatcher dispatcher = request.getRequestDispatcher("createEmployee.jsp");
			      dispatcher.forward(request, response);
		    }
			
			
		}
	
	 
	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		    
		    SkillMasterDAO dao=new SkillMasterDAO();
		   List<SkillMaster> allSkill=dao.getAllSkill();
		   System.out.println("all skill print in this "+allSkill);
		    req.setAttribute("All skill",allSkill);
		  RequestDispatcher dispatcher = req.getRequestDispatcher("createEmployee.jsp");
	        dispatcher.forward(req, resp);
	}
}
