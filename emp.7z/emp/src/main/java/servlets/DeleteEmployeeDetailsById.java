package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeDAO;
import dao.EmployeeSkillDAO;
import entity.Employee;
import entity.SkillMaster;


@WebServlet("/deleteEmployee")
public class DeleteEmployeeDetailsById extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int employeeId=Integer.parseInt(req.getParameter("employeeId"));
		
	
		EmployeeDAO employeeDAO=new EmployeeDAO();
		
		boolean deleteStatus=employeeDAO.deleteEmployeeDetails(employeeId);
	   if(deleteStatus) {
		
			List<Employee> employeeList=employeeDAO.getEmployeeDetails(1,5);
	   	 System.out.println("all employee by click get all employee by delete process "+employeeList);
	   	 
			    req.setAttribute("getAllEmployee",employeeList);
			  RequestDispatcher dispatcher = req.getRequestDispatcher("getAllEmployee.jsp");
		        dispatcher.forward(req, resp);
	   }
		
	
	}

}
