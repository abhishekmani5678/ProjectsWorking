package entity;

import java.util.Date;

public class Employee {
	
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", gender=" + gender + ", name=" + name + ", address=" + address
				+ ", salary=" + salary + ", birthDate=" + birthDate + "]";
	}
	private int employeeId;
	private byte gender;
	private String name,address;
	private Double salary;
	 private Date birthDate;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public byte getGender() {
		return gender;
	}
	public void setGender(byte gender) {
		this.gender = gender;
	}
	public Employee(int employeeId, String name,  String address, byte gender,  Double salary, Date birthDate) {
		super();
		this.employeeId = employeeId;
		this.gender = gender;
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.birthDate = birthDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee( String name,  String address, byte gender,  Double salary, Date birthDate) {
		super();
		this.gender = gender;
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.birthDate = birthDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}