package entity;

public class SkillMaster {
	private int skillId;
	private String skillName;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public SkillMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SkillMaster(String skillName) {
		super();
		this.skillName = skillName;
	}

	public SkillMaster(int skillId, String skillName) {
		super();
		this.skillId = skillId;
		this.skillName = skillName;
	}

	@Override
	public String toString() {
		return "Skill [skillId=" + skillId + ", skillName=" + skillName + "]";
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

}
