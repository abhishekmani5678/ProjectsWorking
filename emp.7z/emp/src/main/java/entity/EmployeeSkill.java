package entity;

public class EmployeeSkill {
	public int employeeId, skillId;

	public EmployeeSkill(int employeeId, int skillId) {
		super();
		this.employeeId = employeeId;
		this.skillId = skillId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public EmployeeSkill() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	@Override
	public String toString() {
		return "SkillMaster [employeeId=" + employeeId + ", skillId=" + skillId + "]";
	}

}
